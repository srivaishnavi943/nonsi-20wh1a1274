/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int main()
{
    int n=153,sum=0,temp;
    temp=n;
    while(n>0)
    {
        int a=n%10;
        sum += a * a * a;
        printf("%d\n", a * a * a);
        n= n/10;
        
    }
    
    printf("%d",sum);
    if(sum=temp){
        printf("\nIt is a armstrong number");
    }


    return 0;
}
