/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int  a,b, max;
    
    cout<<"enter two numbers:  ";
    cin>>a,b;
    
    max =(a>b) ? a:b;
    
    do
    {
        if(max % a == 0 && max % b == 0)
        {
            cout<<"LCM of a and b is ";
            cout<<max;
            
            break;
            
        }
        else
        
        max++;
    }while (true);
        
    
    
    return 0;
}
