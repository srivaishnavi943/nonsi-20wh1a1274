/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a1,a2,d,n,an;
    cout<<"Enter the first element in the series: ";
    cin>>a1;
     
    cout<<"Enter the second element of series: ";
    cin>>a2;
    
    d = a2-a1;
    cout<<"The common difference is: ";
    cout<<d<<endl;
    
    
    cout<<"Enter the value of n: ";
    cin>>n;
    
    an = a1+ (n-1)*d;
    
    cout<<"The Nth term of the series: ";
    cout<<an<<endl;
    

    return 0;
}