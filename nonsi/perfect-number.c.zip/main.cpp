/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int i,n,sum=0;
    
    cout<<"Enter a number";
    cin>>n;
    
    for(i=1; i<n; i++)
    {
        if(n%i ==0 )
        sum = sum+i;
        
    }
    if(n==sum)
    cout<<n<<" is a perfect number";
    
    else
    cout<<n<<" is not a perfect number";
    
    return 0;
}